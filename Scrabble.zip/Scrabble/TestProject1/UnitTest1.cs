using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;

namespace Scrabble
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestConstructeurnaturelJoueur()
        {
            string nomvalide = "toto";
            int reussite = 0;
            Joueur joueur1 = new Joueur(nomvalide);
            if (joueur1.Nom == "toto") reussite++;
            if (joueur1.Score == 0) reussite++;
            if (joueur1.Motstrouves.Count ==0) reussite++;
            if (joueur1.Maincourante.Count==0) reussite++;
            Assert.AreEqual(reussite, 4);
        }
        [TestMethod]
        public void TestConstructeurPartieEncours()
        {
            string filename = "Joueurs.txt";
            Joueur joueur1 = new Joueur(1, filename);
            Assert.AreEqual(joueur1.ToString(), "Le joueur s'appelle toto, il a un score de 56, il a trouve ces mots :  BAT SEBUM LEXEMES");
        }
        [TestMethod]
        public void TestAddMot()
        {
            string mot = "mot";
            Joueur joueur1 = new Joueur("toto");
            joueur1.Add_Mot(mot);
            Assert.AreEqual(joueur1.Motstrouves[0], "mot");
        }
        [TestMethod]
        public void TestAddScore()
        {
            Joueur joueur1 = new Joueur("toto");
            joueur1.Add_Score(45);
            Assert.AreEqual(joueur1.Score, 45);
        }
        [TestMethod]
        public void TestAddMaincourante()
        {
            Joueur joueur1 = new Joueur("toto");
            Jeton jeton1 = new Jeton('A', 1, 9);
            joueur1.Add_Main_Courante(jeton1);
            Assert.AreEqual(joueur1.Maincourante[0], jeton1);
        }
       /* [TestMethod]
        public void TestRemoveMainCourante()
        {
            string filename = "Joueurs.txt";
            Joueur joueur1 = new Joueur(1, filename);
            Jeton jeton1 = new Jeton('A', 1, 9);
            joueur1.Remove_Main_Courante(jeton1);
            Jeton jeton2 = new Jeton('B', 3, 2);
            Assert.AreEqual(joueur1.Maincourante[0],jeton2);
        }
       [TestMethod]
       public void TestConversionLettreJeton()
        {
            Joueur joueur1 = new Joueur("toto");
            Sac_Jetons sacjetons = new Sac_Jetons();
            string lettre = "A";
            Jeton jeton2 = new Jeton('A', 1, 9);
            Jeton jeton1 = joueur1.ConversionLettreJeton(lettre, sacjetons);
            Assert.AreEqual(jeton1, jeton2);
        }*/
       [TestMethod]
       public void Testjetontostring()
        {
            Jeton jeton1 = new Jeton('A', 1, 9);
            Assert.AreEqual(jeton1.ToString(), "Le jeton est la letttre A,  il vaut 1 point(s) et il y a 9 duplicata(s).");
        }
        [TestMethod]
        public void TestSacjetons() //le test est trop long car il affiche chacun des 27 jetons,mais r�alis� dans le main, le test a �t� r�ussi.
        {
            Sac_Jetons sacjetons = new Sac_Jetons();
        }
        [TestMethod]
        public void TestRetire()
        {
            Random r = new Random();
            Sac_Jetons sacjetons = new Sac_Jetons();
            Jeton jeton1 = sacjetons.Retire_Jeton(r);
        } //le random r ne sera pas toujours le m�me on ne peut donc tester, on peut simplement observer que c'est bon dans le main en testant
        [TestMethod]
        public void TestRetirejeton()
        {

        }
    }

}
